<?php
class EXCEPTIONS {
    const NO_RESULT_FOUND = 'No result found';
}
