mysql -u root -e "CREATE DATABASE IF NOT EXISTS development;"
