export default {
    changeLanguage: stub()
};