export default {
    login: stub(),
    logout: stub(),
    checkSession: stub()
};