opensupports_version = '4.11.0';
root = 'http://localhost:3000';
apiRoot = 'http://localhost:3000/api';
globalIndexPath = '';
showLogs = true;
